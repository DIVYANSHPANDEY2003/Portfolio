import React from "react";
import "../Navbar/Navbar";
import { VscMenu } from "react-icons/vsc";
import { VscChromeClose } from "react-icons/vsc";
import { useState } from "react";
import { Link } from "react-scroll";

const Navbar = () => {
  const [menu, setMenu] = useState(false);
  const NavItems = [
    { id: 1, text: "Home" },
    { id: 2, text: "About" },
    { id: 3, text: "Project" },
    { id: 4, text: "Skills" },
    { id: 5, text: "Contact" },
  ];

  return (
    <div className="max -w screen-2xl container mx-auto px-4 md:px-20 w -40 h-16 shadow-md fixed top-0 left-0 rigth-0 z-50 bg-white">
      <div className="flex justify-between items-center h-16">
        <div className="flex space-x-2">
          <img src="/my_image.jpg" alt="Logo" className="w-12 h-12 rounded-full" />
          <h1 className="font-semibold text -xl cursor-pointer">
            Divyans
            <span className="text-green-500 text-2xl">h</span>
            <p className="text-sm">Web Developer</p>
          </h1>
        </div>

        {/*desktop Navbar*/}
        <div>
          <ul className="hidden md:flex space-x-8">
            {NavItems.map(({ id, text }) => (
              <li
                className="hover:scale-105 duration-200 cursor-pointer"
                key={id}
              >
                <Link
                  to={text}
                  smooth={true}
                  duration={500}
                  offset={-70}
                  spy={true}
                  activeClass="active"
                >
                  {text}
                </Link>
              </li>
            ))}
          </ul>
          <div
            onClick={() => setMenu(!menu)}
            className="md:hidden flex flex-col space-y-1"
          >
            {menu ? <VscMenu size={24} /> : <VscChromeClose size={24} />}
          </div>
        </div>
      </div>

      {/*Mobile Menu Navbar8 */}
      {menu && (
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-white z-50">
          <ul className="md:hidden flex flex-col h-screen justify-center items-center space-y-3 text-xl">
            {NavItems.map(({ id, text }) => (
              <li
                className="hover:scale-105 duration-200 font-semibold cursor-pointer"
                key={id}
              >
                <Link onClick={() => setMenu(!menu)}
                  to={text}
                  smooth={true}
                  duration={500}
                  offset={-70}
                  spy={true}
                  activeClass="active"
                >
                  {text}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Navbar;
