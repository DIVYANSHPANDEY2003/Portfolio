import React from 'react';

function About() {
  return (
    <div name="About" className="max-w-screen-2xl container mx-auto px-4 md:px-20 my-20 bg-gray-100 py-10 rounded-lg shadow-lg">
      <h1 className="text-4xl font-bold text-center text-green-700 mb-5">About Me</h1>
      <p className="text-lg text-gray-700 text-center px-5 md:px-20 leading-relaxed">
        I'm a Computer Science & Engineering Undergraduate at the United Institute of Technology. 
        Passionate about software development, I am seeking a challenging internship opportunity 
        to apply and expand my technical skills. With a solid foundation in software engineering, 
        I aspire to work on innovative projects and learn from industry professionals.
      </p>
      
      <div className="mt-10">
        <h1 className="text-2xl font-semibold text-green-700">Education and Training</h1>
        <div className="mt-3 space-y-4 text-gray-700">
          <p>
            <span className="font-semibold">Bachelor of Technology in Computer Science and Engineering</span><br />
            United Institute of Technology, Allahabad, Uttar Pradesh, India. <br />
            <span className="text-sm font-semibold">2023 - 2026</span>
          </p>
          <p>
            <span className="font-semibold">Bachelor of Science in Mathematics and Physics</span><br />
            Allahabad State University, Allahabad, Uttar Pradesh, India. <br />
            <span className="text-sm font-semibold">2020 - 2023</span>
          </p>
          <p>
            <span className="font-semibold">Intermediate in Science</span><br />
            New Angles Sr. Sec. School, Pratapgarh, Uttar Pradesh, India. <br />
            <span className="text-sm font-semibold">2019 - 2020</span>
          </p>
        </div>
      </div>
      
      <div className="mt-10">
        <h1 className="text-2xl font-semibold text-green-700">Skills and Expertise</h1>
        <ul className="list-disc list-inside text-gray-700 mt-3 space-y-2">
          <li>Frontend & Backend Development: HTML, CSS, JavaScript, ReactJS, NodeJS, ExpressJS.</li>
          <li>Programming Languages: Java, Python, MySQL.</li>
          <li>Courses: Object-Oriented Programming, Operating Systems, Data Structures & Algorithms, Database Management Systems.</li>
        </ul>
      </div>
      
      <div className="mt-10">
        <h1 className="text-2xl font-semibold text-green-700">Achievements and Certifications</h1>
        <ul className="list-disc list-inside text-gray-700 mt-3 space-y-2">
          <li>Completed one-week bootcamp on Security Fundamentals & Threat Defense at MNNIT-Allahabad.</li>
          <li>Completed a 4.5-month-long MERN Stack Web Development Bootcamp at CodeHelp.</li>
          <li>Completed a 1-month-long Data Science Bootcamp.</li>
          <li>Completed Core Java Course.</li>
          <li>Completed Basics of Python Course.</li>
        </ul>
      </div>
      
      <div className="mt-10">
        <h1 className="text-2xl font-semibold text-green-700">Mission Statement</h1>
        <p className="text-lg text-gray-700 mt-3 leading-relaxed">
          My mission is to leverage my technical skills and knowledge to develop innovative software solutions 
          that address real-world challenges. I am committed to continuous learning and professional growth, 
          aspiring to contribute positively to the field of software engineering while making a meaningful impact on society.
        </p>
      </div>
    </div>
  );
}

export default About;
